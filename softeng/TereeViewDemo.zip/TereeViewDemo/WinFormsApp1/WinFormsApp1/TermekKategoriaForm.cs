﻿using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsApp1.Data;
using WinFormsApp1.Models;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace WinFormsApp1
{
    public partial class TermekKategoriaForm : Form
    {
        RendelesDbContext _context = new RendelesDbContext();
        public TermekKategoriaForm()
        {
            InitializeComponent();

        }

        private void TermekKategoriaForm_Load(object sender, EventArgs e)
        {
            LoadKategoriak();
        }

        private void LoadKategoriak()
        {
            var kategoriak = (from k in _context.TermekKategoria select k).ToList();

            var fokategoriak = from k in kategoriak where k.SzuloKategoriaId == null select k;

            treeViewKategoriak.Nodes.Clear();

            foreach (var fokategoria in fokategoriak)
            {
                TreeNode fokategoriaNode = CreateTreeNode(fokategoria, kategoriak);
                treeViewKategoriak.Nodes.Add(fokategoriaNode);
            }
        }

        TreeNode CreateTreeNode(TermekKategoria kategoria, List<TermekKategoria> kategoriak)
        {
            TreeNode node = new TreeNode(kategoria.Nev);
            node.Tag = kategoria;

            var gyerekek = from k in kategoriak where k.SzuloKategoriaId == kategoria.KategoriaId select k;
            foreach (var gyerek in gyerekek)
            {
                node.Nodes.Add(CreateTreeNode(gyerek, kategoriak));
            }
            return node;
        }

        private void treeViewKategoriak_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (e.Node != null)
            {
                var kiválasztottTrmekKategoria = (TermekKategoria)e.Node.Tag;

                var termekek = from t in _context.Termek where t.KategoriaId == kiválasztottTrmekKategoria.KategoriaId select t;

                dataGridViewTermekek.DataSource = termekek.ToList();


            }
        }

        private void átenvezésToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (treeViewKategoriak.SelectedNode!=null)
            {
                treeViewKategoriak.SelectedNode.BeginEdit();
            }            
        }

        private void treeViewKategoriak_AfterLabelEdit(object sender, NodeLabelEditEventArgs e)
        {
            if (e.Label != null && !string.IsNullOrEmpty(e.Label))
            {
                TermekKategoria kategoria = (TermekKategoria)e.Node.Tag;
                kategoria.Nev = e.Label;
                _context.SaveChanges();
            }
        }

        private void frissítésToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadKategoriak();
        }

        private void újFőkategóriaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TermekKategoria termekKategoria = new TermekKategoria();
            termekKategoria.Nev = "Új kategória";
            termekKategoria.SzuloKategoriaId = null;
            _context.TermekKategoria.Add(termekKategoria);
            _context.SaveChanges();

            TreeNode node = new TreeNode(termekKategoria.Nev);
            node.Tag = termekKategoria;
            treeViewKategoriak.Nodes.Add(node);

            treeViewKategoriak.SelectedNode = node;
        }

        private void újAlkategóriaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TermekKategoria termekKategoria = new TermekKategoria();
            termekKategoria.Nev = "Új kategória";
            termekKategoria.SzuloKategoriaId = ((TermekKategoria)treeViewKategoriak.SelectedNode.Tag).KategoriaId;

            _context.TermekKategoria.Add(termekKategoria);
            _context.SaveChanges();

            TreeNode node = new TreeNode(termekKategoria.Nev);
            node.Tag = termekKategoria;
            treeViewKategoriak.SelectedNode.Nodes.Add(node);

            treeViewKategoriak.SelectedNode = node;
        }

        private void törlésToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (treeViewKategoriak.SelectedNode.Nodes.Count == 0)
            {
                TermekKategoria kategoria = (TermekKategoria)treeViewKategoriak.SelectedNode.Tag;
                _context.TermekKategoria.Remove(kategoria);
                _context.SaveChanges();

                treeViewKategoriak.SelectedNode.Remove();
            }
            else
            {
                MessageBox.Show("Nem törölhető kategória, mert van al kategóriája!");
            }
        }
    }
}
